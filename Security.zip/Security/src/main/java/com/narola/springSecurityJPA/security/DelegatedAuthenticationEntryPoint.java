package com.narola.springSecurityJPA.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Component
public class DelegatedAuthenticationEntryPoint implements AuthenticationEntryPoint {

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) throws IOException {
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        final Map<String, Object> body = new HashMap<>();
        body.put("code", HttpServletResponse.SC_UNAUTHORIZED);
        body.put("payload", "You need to login first in order to perform this action.");
        final ObjectMapper mapper = new ObjectMapper();
        mapper.writeValue(response.getOutputStream(), body);
        //resolver.resolveException(request, response, null, authException);
//        ResponseVO<String> responseParams = new ResponseVO<>();
//        responseParams.setErrorCode("Oops,Something went wrong");
//        responseParams.setStatusCode(404);
//        responseParams.setMessage("User not authenticated");
//        responseParams.setData("Something went wrong");
//
//        response.resetBuffer();
//        response.setStatus(404);
//        response.setHeader(HttpHeaders.CONTENT_TYPE, "application/json");
//        response.getOutputStream().print(new ObjectMapper().writeValueAsString(responseParams.getData()));
//        response.flushBuffer();
        System.out.println("inside commence method");
    }
}
