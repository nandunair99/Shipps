package com.narola.springSecurityJPA.util;

public class Constants {
    public static final String GETUSERS = "/users";
    public static final String LOGIN = "/login2";
}
