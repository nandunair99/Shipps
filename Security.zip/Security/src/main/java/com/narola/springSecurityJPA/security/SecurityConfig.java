package com.narola.springSecurityJPA.security;

import com.narola.springSecurityJPA.responsehandler.JsonAuthenticationFailureHandler;
import com.narola.springSecurityJPA.responsehandler.JsonAuthenticationSuccessHandler;
import com.narola.springSecurityJPA.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.intercept.AuthorizationFilter;
import org.springframework.security.web.authentication.AnonymousAuthenticationFilter;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.switchuser.SwitchUserFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Autowired
    UserService userDetailService;

    @Autowired
    SwitchUserSuccessHandler switchUserSuccessHandler;

    @Autowired
    SwitchUserFailureHandler switchUserFailureHandler;

    @Autowired
    DelegatedAuthenticationEntryPoint authEntryPoint;

    @Autowired
    JwtAuthenticationFilter jwtAuthenticationFilter;

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration builder) throws Exception {
        return builder.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder encoder() {
        return NoOpPasswordEncoder.getInstance();
    }



    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        AuthenticationManagerBuilder authenticationManagerBuilder = http.getSharedObject(AuthenticationManagerBuilder.class);
        //authenticationManagerBuilder.userDetailsService(userDetailService);
        AuthenticationManager authenticationManager = authenticationManagerBuilder.build();
//        authenticationManagerBuilder.inMemoryAuthentication()
//                .withUser("nandu")
//                .password("abc")
//                .roles("USER");
        http
                .csrf().disable()
                .cors().disable()
                .authenticationManager(authenticationManager)
                .authorizeHttpRequests()
                .mvcMatchers("/login2").permitAll()
                .mvcMatchers("/login/impersonate").hasAnyRole("admin", "ROLE_PREVIOUS_ADMINISTRATOR")
                .mvcMatchers("/logout/impersonate").hasAnyRole("admin", "ROLE_PREVIOUS_ADMINISTRATOR")
                .anyRequest().authenticated()
                .and()
                .exceptionHandling()
                .authenticationEntryPoint(authEntryPoint).and()
                .formLogin().disable()
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
        UserAuthenticationFilter userAuthenticationFilter = new UserAuthenticationFilter("/login2", authenticationManager);
        userAuthenticationFilter.setAuthenticationSuccessHandler(new JsonAuthenticationSuccessHandler(userDetailService));
        userAuthenticationFilter.setAuthenticationFailureHandler(new JsonAuthenticationFailureHandler());
        http.addFilterBefore(userAuthenticationFilter, AnonymousAuthenticationFilter.class);
        http.addFilterBefore(jwtAuthenticationFilter, AnonymousAuthenticationFilter.class);
        http.addFilterAfter(switchUserFilter(), AuthorizationFilter.class);
        return http.build();
    }


    public SwitchUserFilter switchUserFilter() {
        SwitchUserFilter switchUserFilter = new SwitchUserFilter();
        switchUserFilter.setUserDetailsService(userDetailService);
        switchUserFilter.setSuccessHandler(switchUserSuccessHandler);
        switchUserFilter.setFailureHandler(switchUserFailureHandler);
        return switchUserFilter;
    }



}

